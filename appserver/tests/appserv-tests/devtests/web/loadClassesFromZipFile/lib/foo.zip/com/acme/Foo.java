package com.acme;

public class Foo {
    // empty
}
