package com.thaiopensource.datatype.xsd;

interface Measure {
  int getLength(Object obj);
}
