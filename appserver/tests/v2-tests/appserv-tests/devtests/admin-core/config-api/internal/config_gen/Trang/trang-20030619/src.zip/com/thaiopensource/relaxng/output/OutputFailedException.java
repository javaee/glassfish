package com.thaiopensource.relaxng.output;

public class OutputFailedException extends Exception {
}
