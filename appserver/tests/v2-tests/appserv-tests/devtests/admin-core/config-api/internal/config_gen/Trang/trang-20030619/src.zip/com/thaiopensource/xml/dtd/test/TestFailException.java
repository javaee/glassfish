package com.thaiopensource.xml.dtd.test;

public class TestFailException extends Exception {
  public TestFailException(String message) {
    super(message);
  }
}
