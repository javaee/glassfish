package com.thaiopensource.xml.dtd.parse;

/**
 * Thrown for a syntax error in parsing the prolog.
 * @see PrologParser
 */
public class PrologSyntaxException extends Exception { }
