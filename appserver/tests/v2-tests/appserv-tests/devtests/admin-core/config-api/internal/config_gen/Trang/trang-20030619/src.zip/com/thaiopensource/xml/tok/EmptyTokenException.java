package com.thaiopensource.xml.tok;

/**
 * Thrown to indicate that the subarray being tokenized is empty.
 */
public class EmptyTokenException extends TokenException {
}
