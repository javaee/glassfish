package com.thaiopensource.relaxng.edit;

public interface AttributeAnnotationVisitor {
  Object visitAttribute(AttributeAnnotation a);
}
