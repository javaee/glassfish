package com.thaiopensource.relaxng.translate.util;

public class InvalidParamValueException extends Exception {
  public InvalidParamValueException() { }
  public InvalidParamValueException(String message) {
    super(message);
  }
}
