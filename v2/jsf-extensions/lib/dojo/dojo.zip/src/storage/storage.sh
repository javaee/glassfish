#! /bin/bash

mtasc -version 8 -swf Storage.swf -main -header 215:138:10 Storage.as 
