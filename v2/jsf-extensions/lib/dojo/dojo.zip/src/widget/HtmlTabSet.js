/*
	Copyright (c) 2004-2005, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

dojo.require("dojo.widget.TabSet");
dojo.provide("dojo.widget.HtmlTabSet");

dojo.deprecated("dojo.widget.HtmlTabSet", "use dojo.widget.TabSet instead", "0.3");
