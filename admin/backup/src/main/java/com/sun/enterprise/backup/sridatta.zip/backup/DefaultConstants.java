/*
 * StatusConstants.java
 *
 * Created on December 13, 2000, 6:21 AM
 */

package com.sun.enterprise.config.backup;

/**
 *
 * @author  sridatta
 */
public interface DefaultConstants {    
      
    static final String DEFAULT_SNAPSHOT_FILENAME_PREFIX = "snapshot";
    static final String DEFAULT_BACKUP_FILENAME_PREFIX = "backup";
    static final String DEFAULT_BACKUP_HISTORY_FILENAME = "backup_history.txt";
    static final String DEFAULT_STATUS_INFO_FILENAME = "STATUS.TXT";
    
    static final int DEFAULT_MAX_BACKUPS = 5;
    static final int DEFAULT_MAX_SNAPSHOTS = 1;
    
    static final String INTRA_FILENAME_SEPARATOR = "_";
    static final String NEWLINE_CHARACTER = "\n"; 
    static final String HISTORY_FILE_INITIAL_SEPARATOR=">";
    static final String HISTORY_FILE_DATA_SEPARATOR=",";
    static final String HISTORY_FILE_EXTRA_DATA_SEPARATOR_START="(";
    static final String HISTORY_FILE_EXTRA_DATA_SEPARATOR_END=")";
	
	// bnevins - turn on lots of messages...
	static final boolean debug = true;
}
