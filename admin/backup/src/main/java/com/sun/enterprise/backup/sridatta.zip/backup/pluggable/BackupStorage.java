/*
 * BackupStorage.java
 *
 * Created on December 21, 2003, 6:37 PM
 */

package com.sun.enterprise.config.backup.pluggable;

import java.io.IOException;
import com.sun.enterprise.config.backup.BackupException;
import com.sun.enterprise.config.backup.status.Status;
import java.io.File;
/**
 *
 * @author  sridatta
 */
public interface BackupStorage {
    long backup(String[] srcDirs, String dest) throws BackupException;
    
    void createStatusFile(String dest, Status status);
    long restore(File file) throws BackupException ;
	public void deleteTarget();
}
