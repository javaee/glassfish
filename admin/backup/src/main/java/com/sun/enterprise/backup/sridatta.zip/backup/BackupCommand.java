/*
 * BackupCommands.java
 *
 * Created on January 16, 2004, 11:27 AM
 */

package com.sun.enterprise.config.backup;

/**
 * A Java 'enum' for command types
 * @author  bnevins
 */
public class BackupCommand
{
	public static BackupCommand parse(String s)
	{
		s = s.toLowerCase();
		
		for(int i = 0; i < allCommands.length; i++)
		{
			if(s.equals(allCommands[i].name))
				return allCommands[i];
		}

		return null;
	}
		
	
	private BackupCommand(String name)
	{
		this.name = name;
	}
	
	public static BackupCommand backup		= new BackupCommand("backup");
	public static BackupCommand restore		= new BackupCommand("restore");
	public static BackupCommand undorestore = new BackupCommand("undorestore");
	public static BackupCommand listbackups = new BackupCommand("listbackups");
	public static BackupCommand listhistory = new BackupCommand("listhistory");
	private static BackupCommand[]	allCommands = new BackupCommand[] { backup, restore, undorestore, listbackups, listhistory };
	
	private String name;
}


