/*
 * BackupSynchronizer.java
 *
 * Created on December 19, 2003, 11:16 PM
 */

package com.sun.enterprise.config.backup.pluggable;

/**
 *
 * @author  sridatta
 */
public interface BackupSynchronizer {
    
    void lock();
    
    void release();
    
}
