/*
 * BackupStatus.java
 *
 * Created on December 13, 2000, 6:52 AM
 */

package com.sun.enterprise.config.backup.status;

import java.util.Date;
import java.io.File;
import java.io.FileInputStream;
import java.io.EOFException;
import com.sun.enterprise.config.backup.BackupException;
import com.sun.enterprise.config.backup.utils.BackupHelper;
import com.sun.enterprise.config.backup.utils.FactoryHelper;

/**
 * Backup Status is used to keep the status for
 * the backup action.
 * @author  sridatta
 */
public class ListBackupStatus extends BackupStatus {
    
    private String _tmpStringValue;
    public ListBackupStatus(File f) throws BackupException {
        init(f);
    }
    
    /**
     * NYI, needs to parse and initiate the objects fully
     * Fixme
     */
    private void init(File f)  throws BackupException {
    /*   setAbsoluteBackupFileName(f.getAbsolutePath());
        _relativeName = f.getName();
        initUserInfo(f);
     */
        //FIXME NYI
        initStatusInfo(f);
    }
    
    private void initStatusInfo(File file) {
        FileInputStream fis = null;
        String res = "";
        File fReadMe = new File(file, FactoryHelper.getEnv().getStatusInfoFileName());
        try {
            fis = new FileInputStream(fReadMe);
            byte[] buf = new byte[1000];
            
            int len = 0;
            try {
                len = fis.read(buf, 0, buf.length);
            } catch (EOFException eof) {
            }
            res = new String(buf).trim();
            
        } catch(Exception e) {
        } finally {
            try {
                fis.close();
            } catch(Exception ex1) {}
        }
        _tmpStringValue = res;
    }
    /*
    protected String thisToString() {
        String res = super.thisToString();
        
        String userInfo = getUserInfo();
        res += ", Backup Name=" + _relativeName;
        
        if(userInfo != null && !userInfo.equals("") ) {
            res += ", User Info=" + userInfo;
        }
        return res;
    }
    
     */
    public String toString() {
        return _tmpStringValue;
    }
}
