/*
 * StatusConstants.java
 *
 * Created on December 13, 2000, 6:21 AM
 */

package com.sun.enterprise.config.backup.status;

/**
 *
 * @author  sridatta
 */
public interface StatusConstants {
    
    public static final String TYPE_UNKNOWN="type_unknown";
    /**
     * Offline is when the backuprestore functionality
     * is used from commandline without the server running
     */
    public static final String TYPE_OFFLINE="offline";
    
    /**
     * Online is when the functionlity is accessed through
     * admin server
     */
    public static final String TYPE_ONLINE="online";
    
    /**
     * occurs when the status is unknow due
     * to fatal condition or when the status
     * object is created without setting success/failure
     */
    public static final String STATUS_UNKNOWN="status_unknown";
    
    public static final String STATUS_SUCCESS="success";
    
    public static final String STATUS_FAILURE="failure";
    
	public static final String OPERATION_TYPE_UNKNOWN="operation_type_unknown";
    
	/*  bnevins 1/15/04 -- these aren't used anywhere...
    public static final String OPERATION_TYPE_BACKUP="operation_type_backup";
    public static final String OPERATION_TYPE_RESTORE="operation_type_restore";
    public static final String OPERATION_TYPE_UNDO_RESTORE="operation_type_undo_restore";
    */
    
    public static final String STORAGE_TYPE_DIRECTORY="directory";
    public static final String STORAGE_TYPE_ZIP="zip";
}
