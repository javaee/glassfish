/*
 * StatusConstants.java
 *
 * Created on December 13, 2000, 6:21 AM
 */

package com.sun.enterprise.config.backup;

/**
 *
 * @author  sridatta
 */
public interface EnvironmentConstants {    
    static final String DIRS_TO_BACKUP = "directories_to_backup";
    static final String DIR_TO_STORE_BACKUP_FILES = 
                            "directory_to_store_backup_files";
    
    static final String ENVIRONMENT_FACTORY_CLASS = 
                            "backup_environment_factory_class";
    
    static final String EXECUTION_TYPE = "backup_execution_type";
    static final String BACKUP_STORAGE_TYPE = "backup_storage_type";
}
