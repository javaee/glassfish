/*
 * BackupStatus.java
 *
 * Created on December 13, 2000, 6:52 AM
 */

package com.sun.enterprise.config.backup.status;

import com.sun.enterprise.config.backup.pluggable.EnvironmentFactory;
import com.sun.enterprise.config.backup.BackupException;
import com.sun.enterprise.config.backup.utils.BackupHelper;


/**
 *
 * @author  sridatta
 */
public class UndoRestoreStatus extends Status {
    
    /**
     * This file is used to undo restore operation
     */
    private String _absSnapShotFile;
    
    /** Creates a new instance of BackupStatus */
    public UndoRestoreStatus() {
    }
    public UndoRestoreStatus(String name) throws BackupException {
        super(true);
        _absSnapShotFile = name;
    }
    
    public String thisToString() {
        return "SnapShot File= " + _absSnapShotFile;
    }
    
    /*
    public static UndoRestoreStatus createFailedUndoRestoreStatus1(String msg) {
        UndoRestoreStatus rs = new UndoRestoreStatus();
        BackupHelper.setExceptionInStatus(rs, new BackupException(msg));
        return rs;
    }
     */
    
    
    public String getOperation() {
        return "undoRestore";
    }
    
    
}
