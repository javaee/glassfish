/*
 * BackupException.java
 *
 * Created on December 16, 2003, 12:18 AM
 */

package com.sun.enterprise.config.backup;

/**
 *
 * @author  sridatta
 */
public class BackupException extends Exception {
    private final String _code;

    public BackupException(String code, String s) { 
        super(s);
        _code = code;
    }
    
    public BackupException(String code, String s, Exception e) {
        super(s,e);
        _code = code;
    }
    
     public String getCode() {
         return _code;
     }
    
}
