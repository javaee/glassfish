/*
 * LogHelper.java
 *
 * Created on December 13, 2000, 9:20 AM
 */

package com.sun.enterprise.config.backup.utils;

/**
 * NYI FIXME
 * @author  sridatta
 */
public class LocalStringsHelper {
    
    /** Creates a new instance of LogHelper */
    public LocalStringsHelper() {
    }

    public static String getString(String str) {
        return str;
    }
    
    public static String getString(String str, Object param1) {
        return str;
    }
}
