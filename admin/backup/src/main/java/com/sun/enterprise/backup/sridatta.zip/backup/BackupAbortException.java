/*
 * BackupAbortException.java
 *
 * Created on December 24, 2003, 10:03 AM
 */

package com.sun.enterprise.config.backup;

/**
 *
 * @author  sridatta
 */
public class BackupAbortException extends RuntimeException {
    private final String _code;
    
    /** Creates a new instance of BackupAbortException */
    public BackupAbortException(String code, String msg) {
        super(msg);
        _code = code;
    }
    
     public BackupAbortException(String code, String s, Exception e) {
        super(s,e);
        _code = code;
    }
    
     public String getCode() {
         return _code;
     }
}
