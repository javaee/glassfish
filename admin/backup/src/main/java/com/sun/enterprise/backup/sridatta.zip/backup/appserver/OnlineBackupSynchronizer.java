/*
 * OnlineBackupSynchronizer.java
 *
 * Created on December 19, 2003, 11:25 PM
 */

package com.sun.enterprise.config.backup.appserver;

import com.sun.enterprise.config.backup.pluggable.BackupSynchronizer;
/**
 *
 * @author  sridatta
 */
public class OnlineBackupSynchronizer implements BackupSynchronizer {
    
    /** Creates a new instance of OnlineBackupSynchronizer */
    public OnlineBackupSynchronizer() {
    }
    
    public void lock() {
    }    
    
    public void release() {
    }    
    
}
