/*
 * EnvironmentFactory.java
 *
 * Created on December 15, 2003, 10:33 PM
 */

package com.sun.enterprise.config.backup.appserver;

import com.sun.enterprise.config.backup.pluggable.BackupSynchronizer;

/**
 * provides a basic implementation of factory. Users can
 * extend this class and implement required methods and set their
 * class in environment variable ENVIRONMENT_FACTORY_CLASS. The
 * statis create method in this class reads the variable and
 * instantiates the class. Note that the implemented factory
 * needs a no arg constructor.
 *
 * @author  sridatta
 */
public class EnvironmentFactory extends 
    com.sun.enterprise.config.backup.pluggable.EnvironmentFactory {
    
 /*   protected BackupEnvironment createBackupEnvironment() {
        return new DefaultBackupEnvironment();
    }
    
    protected ActiveAssistance createActiveAssistance() {
        return new DefaultActiveAssistance();
    }
   
  */ 
        
    protected BackupSynchronizer getOfflineBackupSynchronizer() {
        return new OfflineBackupSynchronizer();
    }
    
    protected BackupSynchronizer getOnlineBackupSynchronizer() {
        return new OnlineBackupSynchronizer();
    }
}
