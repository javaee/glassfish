/*
 * BackupException.java
 *
 * Created on December 16, 2003, 12:18 AM
 */

package com.sun.enterprise.config.backup;

/**
 *
 * @author  sridatta
 */
public abstract class BackupRuntimeException extends RuntimeException {
    public BackupRuntimeException(String s) {
        super(s);
    }
    
    public BackupRuntimeException(String s, Exception e) {
        super(s,e);
    }
    
}
