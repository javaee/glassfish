/*
 * ActiveAssistance.java
 *
 * Created on December 25, 2003, 12:47 PM
 */

package com.sun.enterprise.config.backup.pluggable;
import com.sun.enterprise.config.backup.status.Status;

/**
 * Users can plug in extra information that is added to the status automatically.
 * @author  sridatta
 */
public interface ActiveAssistance {
     
    String getDiagnosabilityInfo(Status s);
    
    String getDidYouKnow(Status s);
}
