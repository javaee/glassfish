/*
 * StatusHolder.java
 *
 * Created on December 24, 2003, 9:58 AM
 */

package com.sun.enterprise.config.backup;

import com.sun.enterprise.config.backup.status.Status;

/**
 *
 * @author  sridatta
 */
public class StatusRegistry {
    
    /** Creates a new instance of StatusHolder */
    public StatusRegistry() {
    }
    
    private static ThreadLocal _threadLocalStatus = 
                            new ThreadLocal();

    public static Status getStatus() {
        return (Status)_threadLocalStatus.get();
    }

    public static void setStatus(Status ctx) {
        _threadLocalStatus.set(ctx);
    }   
}
