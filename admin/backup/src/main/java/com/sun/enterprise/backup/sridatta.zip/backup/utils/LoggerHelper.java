/*
 * LogHelper.java
 *
 * Created on December 13, 2000, 9:20 AM
 */

package com.sun.enterprise.config.backup.utils;

/**
 * LoggerHelper works as a normal Logger in ONLINE mode
 * It needs to be turned on explicitly in OFFLINE mode 
 * so that output on the client is not cluttered
 *
 * @author  sridatta
 */
public class LoggerHelper {
    
    /** Creates a new instance of LogHelper */
    public LoggerHelper() {
    }
    
    public static void fine(String message) {
        //tbd FIXME NYI
        System.out.println(message);
    }
    
    public static void info(String message) {
        //tbd FIXME NYI
        System.out.println(message);
    }
    
    public static void info(String message, Throwable exception) {
        System.out.println(message);
        exception.printStackTrace();
    }
    
    public static void fine(String message, Throwable exception) {
        System.out.println(message);
        exception.printStackTrace();
    }
    public static void error(String message, Throwable exception) {
        System.out.println(message);
        exception.printStackTrace();
    }
    
     public static void warning(String message, Throwable exception) {
        System.out.println(message);
        exception.printStackTrace();
    }
     
       public static void warning(String message) {
        System.out.println(message);
    }
       
    
}
